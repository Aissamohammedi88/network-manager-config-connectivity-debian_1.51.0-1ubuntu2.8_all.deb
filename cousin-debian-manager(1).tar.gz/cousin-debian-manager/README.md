# 🕊️ Cousin Debian Manager

**Gestionnaire de paquets Debian** — Next.js 16 + TypeScript + Prisma + SQLite
*En hommage au créateur originel — Repose en paix.*

---

## 🚀 Installation en 1 commande

```bash
# 1) Extraire l'archive
tar -xzf cousin-debian-manager.tar.gz
cd cousin-debian-manager

# 2) Lancer TOUT
bash launch.sh
```

Le script fait **tout** automatiquement :
- ✅ Vérifie `bun` + `node` (installe bun si absent)
- ✅ `bun install` (si `node_modules` absent)
- ✅ Initialise la base SQLite + schéma Prisma
- ✅ Lance le seed (21 paquets + 5 dépôts + 3 hommages)
- ✅ Démarre Next.js sur `http://localhost:3000`
- ✅ Attend que le serveur réponde (max 30s)
- ✅ Affiche les URLs + suit le log en direct

---

## ⏹️ Arrêt

```bash
bash launch.sh stop
```

Ou `Ctrl+C` dans le terminal (le serveur reste vivant en arrière-plan).

---

## 📦 Contenu de l'archive

```
cousin-debian-manager/
├── launch.sh                 ← LE SCRIPT À LANCER (1 commande)
├── README.md                 ← Ce fichier
├── package.json              ← Dépendances (Next.js, Prisma, shadcn/ui…)
├── bun.lock                  ← Versions verrouillées
├── next.config.ts
├── tsconfig.json
├── tailwind.config.ts
├── postcss.config.mjs
├── eslint.config.mjs
├── components.json           ← Config shadcn/ui
├── .env                      ← DATABASE_URL (SQLite)
├── .gitignore
├── prisma/
│   └── schema.prisma         ← 4 modèles : Package, Repository, InstallLog, Memorial
├── public/
│   ├── logo.svg
│   └── robots.txt
├── scripts/
│   ├── launch.sh             ← (doublon du launcher racine)
│   └── seed.ts               ← Seed : 21 paquets + 5 dépôts + 3 hommages
└── src/
    ├── app/
    │   ├── layout.tsx
    │   ├── page.tsx          ← Page principale (4 onglets)
    │   ├── globals.css
    │   └── api/              ← 7 routes REST
    │       ├── packages/
    │       │   ├── route.ts
    │       │   ├── install/route.ts
    │       │   └── remove/route.ts
    │       ├── repositories/route.ts
    │       ├── memorial/route.ts
    │       ├── stats/route.ts
    │       └── logs/route.ts
    ├── components/ui/        ← 30+ composants shadcn/ui
    ├── hooks/
    │   ├── use-mobile.ts
    │   └── use-toast.ts
    └── lib/
        ├── db.ts             ← Client Prisma
        └── utils.ts
```

---

## 🌐 Accès

| URL | Description |
|---|---|
| `http://localhost:3000` | Page principale (4 onglets) |
| `http://localhost:3000/api/stats` | Statistiques JSON |
| `http://localhost:3000/api/packages` | Liste des paquets |
| `http://localhost:3000/api/memorial` | Livre d'or |

---

## 🎯 Fonctionnalités

- **Catalogue de 21 paquets Debian** : apt, dpkg, systemd, git, nginx, docker.io,
  network-manager-config-connectivity-debian, etc.
- **Recherche + filtres** par statut (installé/disponible) et section
- **Vue détaillée** : version, architecture, dépendances, mainteneur, homepage
- **Installation/suppression simulée** avec sortie terminal réaliste
- **Terminal intégré** style macOS (vert sur noir)
- **Gestion des dépôts** : Debian Stable/Testing/Unstable + Ubuntu + Security
- **Bouton "Installer le .deb local"** → exécute
  `sudo apt install ./network-manager-config-connectivity-debian_1.46.0-1ubuntu2.8_all.deb`
- **Livre d'or mémorial** : déposez un hommage au créateur défunt

---

## 🛠️ Stack technique

- **Framework** : Next.js 16 (App Router, Turbopack)
- **Langage** : TypeScript 5
- **Base de données** : SQLite via Prisma ORM
- **UI** : Tailwind CSS 4 + shadcn/ui (New York)
- **Runtime** : Bun
- **Notifications** : Sonner

---

## 📝 Personnalisation

### Changer le nom/dates du créateur dans l'hommage

Éditez `scripts/seed.ts` (section `memorial.create`) puis relancez :

```bash
bash launch.sh stop
rm -f db/custom.db
bash launch.sh
```

### Ajouter des paquets

Éditez `scripts/seed.ts` (tableau `packages`) ou ajoutez-les via l'API :

```bash
curl -X POST http://localhost:3000/api/packages/install \
  -H "Content-Type: application/json" \
  -d '{"fileName":"mon-paquet_1.0_amd64.deb"}'
```

---

**En hommage au créateur originel. Ton code continue de faire tourner le monde.** 🕊️
