import { db } from '../src/lib/db'

async function seed() {
  console.log('🌱 Début du seed...')

  // Nettoyage
  await db.installLog.deleteMany()
  await db.package.deleteMany()
  await db.repository.deleteMany()
  await db.memorial.deleteMany()

  // === Dépôts ===
  const repos = [
    { name: 'Debian Stable (Bookworm)', url: 'http://deb.debian.org/debian', suite: 'bookworm', components: 'main contrib non-free', enabled: true, packages: 64512 },
    { name: 'Debian Testing (Trixie)', url: 'http://deb.debian.org/debian', suite: 'trixie', components: 'main contrib non-free', enabled: true, packages: 68104 },
    { name: 'Debian Unstable (Sid)', url: 'http://deb.debian.org/debian', suite: 'sid', components: 'main contrib non-free', enabled: false, packages: 71250 },
    { name: 'Ubuntu Universe (Noble)', url: 'http://archive.ubuntu.com/ubuntu', suite: 'noble', components: 'universe multiverse', enabled: true, packages: 58921 },
    { name: 'Debian Security', url: 'http://security.debian.org/debian-security', suite: 'bookworm-security', components: 'main contrib', enabled: true, packages: 1248 },
  ]
  for (const r of repos) {
    await db.repository.create({ data: r })
  }

  // === Paquets ===
  const packages = [
    // Le paquet mentionné par l'utilisateur
    {
      name: 'network-manager-config-connectivity-debian',
      version: '1.46.0-1ubuntu2.8',
      architecture: 'all',
      description: 'Configuration de connectivité NetworkManager pour les serveurs Debian. Fournit les fichiers de configuration pour la vérification de connectivité utilisée par NetworkManager, spécifiquement adaptée aux systèmes Debian et Ubuntu.',
      maintainer: 'Ubuntu Developers <ubuntu-devel-discuss@lists.ubuntu.com>',
      section: 'net',
      priority: 'optional',
      installedSize: 32,
      depends: 'network-manager',
      recommends: '',
      homepage: 'https://networkmanager.dev/',
      repository: 'main',
      status: 'available',
      fileName: 'network-manager-config-connectivity-debian_1.46.0-1ubuntu2.8_all.deb',
      fileSize: 8724,
    },
    {
      name: 'network-manager',
      version: '1.46.0-1',
      architecture: 'amd64',
      description: 'NetworkManager est un démon système qui gère les connexions réseau, tentant de garder une connectivité active quand elle est disponible. Il gère Ethernet, Wi-Fi, mobile broadband (3G), PPPoE, et bien plus.',
      maintainer: 'Utopia Maintenance Team <pkg-utopia-maintainers@lists.alioth.debian.org>',
      section: 'net',
      priority: 'important',
      installedSize: 6144,
      depends: 'dbus, libnm0, libglib2.0-0, libgnutls30, policykit-1',
      recommends: 'dnsmasq-base, modemmanager, wpasupplicant',
      homepage: 'https://networkmanager.dev/',
      repository: 'main',
      status: 'installed',
      fileName: 'network-manager_1.46.0-1_amd64.deb',
      fileSize: 1843200,
    },
    {
      name: 'apt',
      version: '2.7.14',
      architecture: 'amd64',
      description: 'Gestionnaire de paquets en ligne de commande. APT fournit une interface haut niveau pour le système de gestion de paquets dpkg, permettant l\'installation, la mise à jour et la suppression de paquets Debian.',
      maintainer: 'APT Development Team <deity@lists.debian.org>',
      section: 'admin',
      priority: 'required',
      installedSize: 4196,
      depends: 'adduser, gpgv, libapt-pkg6.0, libgnutls30, debian-archive-keyring',
      recommends: '',
      homepage: 'https://wiki.debian.org/Apt',
      repository: 'main',
      status: 'installed',
      fileName: 'apt_2.7.14_amd64.deb',
      fileSize: 1372160,
    },
    {
      name: 'dpkg',
      version: '1.22.6',
      architecture: 'amd64',
      description: 'Système de gestion de paquets Debian. dpkg est le programme de bas niveau pour installer, supprimer et interroger les paquets logiciels Debian.',
      maintainer: 'Dpkg Developers <debian-dpkg@lists.debian.org>',
      section: 'admin',
      priority: 'required',
      installedSize: 6724,
      depends: 'tar, libbz2-1.0, liblzma5, zlib1g',
      recommends: '',
      homepage: 'https://wiki.debian.org/Teams/Dpkg',
      repository: 'main',
      status: 'installed',
      fileName: 'dpkg_1.22.6_amd64.deb',
      fileSize: 2129920,
    },
    {
      name: 'systemd',
      version: '255.4-1',
      architecture: 'amd64',
      description: 'systemd est un système et gestionnaire de services pour Linux, conçu pour remplacer SysV init. Il fournit une gestion parallèle des services, le suivi des processus via cgroups, et plus encore.',
      maintainer: 'Debian systemd Maintainers <pkg-systemd-maintainers@lists.alioth.debian.org>',
      section: 'admin',
      priority: 'important',
      installedSize: 18432,
      depends: 'libsystemd0, dbus, kmod, util-linux',
      recommends: '',
      homepage: 'https://systemd.io/',
      repository: 'main',
      status: 'installed',
      fileName: 'systemd_255.4-1_amd64.deb',
      fileSize: 5242880,
    },
    {
      name: 'firefox-esr',
      version: '115.10.0esr-1',
      architecture: 'amd64',
      description: 'Mozilla Firefox est un navigateur web libre et open-source, avec une emphase sur la flexibilité, la sécurité et la confidentialité. Version ESR (Extended Support Release) pour les déploiements stables.',
      maintainer: 'Maintainers of Mozilla packages <pkg-mozilla-maintainers@lists.debian.org>',
      section: 'web',
      priority: 'optional',
      installedSize: 215040,
      depends: 'libgtk-3-0, libstdc++6, libnss3, libasound2',
      recommends: 'libcanberra0, pulseaudio',
      homepage: 'https://www.mozilla.org/firefox/',
      repository: 'main',
      status: 'installed',
      fileName: 'firefox-esr_115.10.0esr-1_amd64.deb',
      fileSize: 52428800,
    },
    {
      name: 'vim',
      version: '2:9.1.0135-1',
      architecture: 'amd64',
      description: 'Vi IMproved - éditeur de texte amélioré pour programmeurs. Vim est un éditeur hautement configurable construit pour permettre l\'édition efficace de texte.',
      maintainer: 'Debian Vim Maintainers <pkg-vim-maintainers@lists.debian.org>',
      section: 'editors',
      priority: 'optional',
      installedSize: 3120,
      depends: 'vim-common, vim-runtime, libacl1, libc6, libtinfo6',
      recommends: '',
      homepage: 'https://www.vim.org/',
      repository: 'main',
      status: 'installed',
      fileName: 'vim_9.1.0135-1_amd64.deb',
      fileSize: 1048576,
    },
    {
      name: 'git',
      version: '1:2.43.0-1',
      architecture: 'amd64',
      description: 'Git est un système de contrôle de versions distribué rapide et évolutif avec un ensemble de commandes exceptionnellement riche qui fournit des opérations avancées et un accès complet aux internals.',
      maintainer: 'Jonathan Carter <jcarter@debian.org>',
      section: 'vcs',
      priority: 'optional',
      installedSize: 35840,
      depends: 'libc6, zlib1g, libcurl4, libexpat1, perl',
      recommends: 'ssh-client, patch, less',
      homepage: 'https://git-scm.com/',
      repository: 'main',
      status: 'installed',
      fileName: 'git_2.43.0-1_amd64.deb',
      fileSize: 7340032,
    },
    {
      name: 'htop',
      version: '3.3.0-1',
      architecture: 'amd64',
      description: 'htop est un visualiseur de processus interactif pour les systèmes Linux. Il offre une vue en couleur, en temps réel, des processus en cours d\'exécution.',
      maintainer: 'Daniel Lange <dl.ml1@usrlocal.de>',
      section: 'utils',
      priority: 'optional',
      installedSize: 348,
      depends: 'libc6, libncursesw6, libtinfo6',
      recommends: '',
      homepage: 'https://htop.dev/',
      repository: 'main',
      status: 'available',
      fileName: 'htop_3.3.0-1_amd64.deb',
      fileSize: 118784,
    },
    {
      name: 'curl',
      version: '8.7.1-1',
      architecture: 'amd64',
      description: 'curl est un outil en ligne de commande pour transférer des données via des URL. Il supporte HTTP, HTTPS, FTP, FTPS, SCP, SFTP, TFTP, et plus.',
      maintainer: 'curl maintainers <pkg-curl@debian.org>',
      section: 'web',
      priority: 'optional',
      installedSize: 384,
      depends: 'libc6, libcurl4, zlib1g, libssh2-1',
      recommends: '',
      homepage: 'https://curl.se/',
      repository: 'main',
      status: 'installed',
      fileName: 'curl_8.7.1-1_amd64.deb',
      fileSize: 131072,
    },
    {
      name: 'nginx',
      version: '1.25.5-1',
      architecture: 'amd64',
      description: 'nginx est un serveur HTTP et reverse proxy haute performance, ainsi qu\'un proxy mail et un proxy TCP/UDP générique.',
      maintainer: 'Debian Nginx Maintainers <nginx@debian.org>',
      section: 'httpd',
      priority: 'optional',
      installedSize: 1843,
      depends: 'libc6, libpcre2-8-0, zlib1g, openssl',
      recommends: '',
      homepage: 'https://nginx.org/',
      repository: 'main',
      status: 'available',
      fileName: 'nginx_1.25.5-1_amd64.deb',
      fileSize: 622592,
    },
    {
      name: 'docker.io',
      version: '24.0.7-1',
      architecture: 'amd64',
      description: 'Docker est une plateforme ouverte pour les développeurs et administrateurs systèmes pour construire, livrer et exécuter des applications distribuées.',
      maintainer: 'Docker Composers <docker@packages.debian.org>',
      section: 'admin',
      priority: 'optional',
      installedSize: 65536,
      depends: 'containerd, runc, iptables, libseccomp2',
      recommends: '',
      homepage: 'https://www.docker.com/',
      repository: 'main',
      status: 'available',
      fileName: 'docker.io_24.0.7-1_amd64.deb',
      fileSize: 20971520,
    },
    {
      name: 'python3',
      version: '3.11.8-1',
      architecture: 'amd64',
      description: 'Python est un langage de programmation interprété, interactif, orienté objet, de haut niveau. Cette version fournit l\'interpréteur Python 3 standard.',
      maintainer: 'Matthias Klose <doko@debian.org>',
      section: 'python',
      priority: 'important',
      installedSize: 7168,
      depends: 'libpython3-stdlib, python3-minimal, libc6',
      recommends: '',
      homepage: 'https://www.python.org/',
      repository: 'main',
      status: 'installed',
      fileName: 'python3_3.11.8-1_amd64.deb',
      fileSize: 2244608,
    },
    {
      name: 'nodejs',
      version: '18.19.1~dfsg-1',
      architecture: 'amd64',
      description: 'Node.js est une plateforme événementielle en JavaScript pour construire des applications réseau évolutives. Il permet d\'écrire des programmes serveur performants en JavaScript.',
      maintainer: 'Debian Javascript Maintainers <pkg-javascript-devel@lists.alioth.debian.org>',
      section: 'javascript',
      priority: 'optional',
      installedSize: 122880,
      depends: 'libc6, libstdc++6, openssl',
      recommends: 'ca-certificates, npm',
      homepage: 'https://nodejs.org/',
      repository: 'main',
      status: 'available',
      fileName: 'nodejs_18.19.1~dfsg-1_amd64.deb',
      fileSize: 31457280,
    },
    {
      name: 'gnome-shell',
      version: '46.1-1',
      architecture: 'amd64',
      description: 'GNOME Shell est l\'interface graphique principale de l\'environnement de bureau GNOME. Elle fournit le bureau, le sélecteur de fenêtres et la vue d\'ensemble des activités.',
      maintainer: 'Debian GNOME Maintainers <pkg-gnome-maintainers@lists.alioth.debian.org>',
      section: 'gnome',
      priority: 'optional',
      installedSize: 5120,
      depends: 'mutter, gjs, gnome-session, libmutter-12-0',
      recommends: 'gnome-control-center, gnome-shell-extensions',
      homepage: 'https://wiki.gnome.org/Projects/GnomeShell',
      repository: 'main',
      status: 'available',
      fileName: 'gnome-shell_46.1-1_amd64.deb',
      fileSize: 1835008,
    },
    {
      name: 'mariadb-server',
      version: '1:10.11.7-2',
      architecture: 'amd64',
      description: 'MariaDB est un serveur de base de données développé par la communauté, fork de MySQL. Il fournit des fonctionnalités avancées pour les applications de base de données SQL.',
      maintainer: 'Debian MySQL Maintainers <pkg-mysql-maintainers@lists.alioth.debian.org>',
      section: 'database',
      priority: 'optional',
      installedSize: 102400,
      depends: 'mariadb-server-10.11, mariadb-client',
      recommends: '',
      homepage: 'https://mariadb.org/',
      repository: 'main',
      status: 'available',
      fileName: 'mariadb-server_10.11.7-2_amd64.deb',
      fileSize: 4194304,
    },
    {
      name: 'ffmpeg',
      version: '7:5.1.4-1',
      architecture: 'amd64',
      description: 'FFmpeg est un framework multimédia complet capable de décoder, encoder, transcoder, muxer, demuxer, streamer, filtrer et jouer presque tout ce que les humains et les machines ont créé.',
      maintainer: 'Debian Multimedia Maintainers <pkg-multimedia-maintainers@lists.alioth.debian.org>',
      section: 'video',
      priority: 'optional',
      installedSize: 98304,
      depends: 'libavcodec59, libavformat59, libavutil57, libswscale6',
      recommends: 'libavfilter-extra8',
      homepage: 'https://ffmpeg.org/',
      repository: 'main',
      status: 'available',
      fileName: 'ffmpeg_5.1.4-1_amd64.deb',
      fileSize: 3932160,
    },
    {
      name: 'gimp',
      version: '2.10.36-1',
      architecture: 'amd64',
      description: 'GIMP (GNU Image Manipulation Program) est un éditeur d\'images raster utilisé pour le retouchage, l\'édition d\'image, le dessin libre, la conversion entre différents formats d\'image, et plus.',
      maintainer: 'Debian GNOME Maintainers <pkg-gnome-maintainers@lists.alioth.debian.org>',
      section: 'graphics',
      priority: 'optional',
      installedSize: 40960,
      depends: 'libgtk-3-0, libgimp2.0-0, libc6, libgegl-0.4-0',
      recommends: 'gimp-data-extras, gimp-help',
      homepage: 'https://www.gimp.org/',
      repository: 'main',
      status: 'available',
      fileName: 'gimp_2.10.36-1_amd64.deb',
      fileSize: 15728640,
    },
    {
      name: 'openssh-server',
      version: '1:9.6p1-1',
      architecture: 'amd64',
      description: 'Serveur SSH sécurisé. OpenSSH fournit une connectivité chiffrée pour les connexions distantes, le transfert de fichiers et le tunneling.',
      maintainer: 'Debian OpenSSH Maintainers <debian-ssh@lists.debian.org>',
      section: 'net',
      priority: 'optional',
      installedSize: 5120,
      depends: 'openssh-client, openssh-sftp-server, libc6, libssl3',
      recommends: '',
      homepage: 'https://www.openssh.com/',
      repository: 'main',
      status: 'installed',
      fileName: 'openssh-server_9.6p1-1_amd64.deb',
      fileSize: 1048576,
    },
    {
      name: 'vlc',
      version: '3.0.20-1',
      architecture: 'amd64',
      description: 'VLC est un lecteur multimédia et un framework libre et open-source qui lit la plupart des fichiers multimédia, ainsi que les DVD, CD audio, VCD, et divers protocoles de streaming.',
      maintainer: 'Debian Multimedia Maintainers <pkg-multimedia-maintainers@lists.alioth.debian.org>',
      section: 'video',
      priority: 'optional',
      installedSize: 51200,
      depends: 'libc6, libqt5core5a, libqt5gui5, libx11-6',
      recommends: 'vlc-plugin-samba, vlc-plugin-access-extra',
      homepage: 'https://www.videolan.org/',
      repository: 'main',
      status: 'available',
      fileName: 'vlc_3.0.20-1_amd64.deb',
      fileSize: 10485760,
    },
    {
      name: 'wireguard',
      version: '1.0.20210914-1',
      architecture: 'amd64',
      description: 'WireGuard est un VPN rapide, moderne et sécurisé qui utilise une cryptographie à la pointe de l\'état de l\'art. Il est plus rapide, plus simple, plus lean et plus utile que IPSec.',
      maintainer: 'Daniel Kahn Gillmor <dkg@fifthhorseman.net>',
      section: 'net',
      priority: 'optional',
      installedSize: 384,
      depends: 'wireguard-modules, wireguard-tools',
      recommends: '',
      homepage: 'https://www.wireguard.com/',
      repository: 'main',
      status: 'available',
      fileName: 'wireguard_1.0.20210914-1_amd64.deb',
      fileSize: 163840,
    },
  ]

  for (const p of packages) {
    await db.package.create({ data: p })
  }

  // === Mémorial : hommage au cousin ===
  const memorial = [
    {
      author: 'Votre Cousin',
      years: '1985 - 2024',
      message: 'Créateur passionné du gestionnaire de paquets Debian originel. Ton héritage vit à travers chaque paquet installé. Tu nous as appris que la liberté logicielle est un combat noble. Repose en paix.',
      relation: 'Cousin et créateur',
    },
    {
      author: 'La Communauté Debian',
      years: '1993 - Toujours',
      message: 'En hommage à tous les développeurs Debian qui ont quitté cette terre. Leur code continue de faire tourner le monde. Debian : le système d\'exploitation universel.',
      relation: 'Famille Debian',
    },
    {
      author: 'Ian Murdock',
      years: '1973 - 2015',
      message: 'Fondateur du projet Debian. Sans lui, rien de tout cela ne serait possible. Son nom vit à travers chaque dépôt et chaque paquet que nous installons aujourd\'hui.',
      relation: 'Fondateur du projet Debian',
    },
  ]

  for (const m of memorial) {
    await db.memorial.create({ data: m })
  }

  // === Logs d'installation initiaux ===
  const apt = await db.package.findUnique({ where: { name: 'apt' } })
  const dpkg = await db.package.findUnique({ where: { name: 'dpkg' } })
  const ssh = await db.package.findUnique({ where: { name: 'openssh-server' } })
  const nm = await db.package.findUnique({ where: { name: 'network-manager' } })

  if (apt) {
    await db.installLog.create({
      data: { packageId: apt.id, action: 'install', status: 'success', output: 'Lecture des listes de paquets... Terminé\nConstruction de l\'arbre des dépendances... Terminé\napt (2.7.14) installé avec succès.' },
    })
  }
  if (dpkg) {
    await db.installLog.create({
      data: { packageId: dpkg.id, action: 'install', status: 'success', output: 'Dépaquetage de dpkg...\nConfiguration de dpkg (1.22.6)...\nTraitement des déclencheurs pour man-db...' },
    })
  }
  if (ssh) {
    await db.installLog.create({
      data: { packageId: ssh.id, action: 'install', status: 'success', output: 'Created symlink /etc/systemd/system/sshd.service.\nopenssh-server (1:9.6p1-1) configuré avec succès.' },
    })
  }
  if (nm) {
    await db.installLog.create({
      data: { packageId: nm.id, action: 'install', status: 'success', output: 'NetworkManager (1.46.0-1) installé.\nDémarrage du service NetworkManager... [OK]' },
    })
  }

  console.log(`✅ Seed terminé : ${packages.length} paquets, ${repos.length} dépôts, ${memorial.length} hommages`)
}

seed()
  .catch((e) => {
    console.error('❌ Erreur lors du seed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
