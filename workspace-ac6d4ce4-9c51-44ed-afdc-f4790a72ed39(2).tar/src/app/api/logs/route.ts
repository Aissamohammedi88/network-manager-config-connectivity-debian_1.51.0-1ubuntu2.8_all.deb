import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/logs
export async function GET() {
  const logs = await db.installLog.findMany({
    orderBy: { createdAt: 'desc' },
    take: 50,
    include: { package: true },
  })
  return NextResponse.json({ logs })
}
