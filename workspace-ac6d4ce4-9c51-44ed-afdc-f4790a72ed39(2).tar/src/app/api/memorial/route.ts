import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/memorial
export async function GET() {
  const memorials = await db.memorial.findMany({
    orderBy: { createdAt: 'asc' },
  })
  return NextResponse.json({ memorials })
}

// POST /api/memorial - ajouter un hommage
export async function POST(req: NextRequest) {
  const { author, years, message, relation } = await req.json()
  if (!author || !message) {
    return NextResponse.json({ error: 'author et message requis' }, { status: 400 })
  }
  const memorial = await db.memorial.create({
    data: {
      author,
      years: years || '',
      message,
      relation: relation || 'Hommage',
    },
  })
  return NextResponse.json({ memorial })
}
