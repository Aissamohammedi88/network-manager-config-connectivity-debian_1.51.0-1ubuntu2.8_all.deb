import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// POST /api/packages/install
// body: { name: string } ou { fileName: string } (pour installer un .deb local)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { name, fileName } = body

    let pkg = null
    if (name) {
      pkg = await db.package.findUnique({ where: { name } })
    } else if (fileName) {
      pkg = await db.package.findFirst({ where: { fileName } })
    }

    if (!pkg) {
      // Si on n'a pas trouvé, on crée une entrée pour un .deb local
      if (fileName) {
        pkg = await db.package.create({
          data: {
            name: fileName.replace(/_[^_]+\.deb$/, ''),
            version: fileName.match(/_([^_]+)_.*\.deb$/)?.[1] || 'unknown',
            architecture: fileName.match(/_([a-z0-9]+)\.deb$/)?.[1] || 'all',
            description: `Paquet local installé depuis ${fileName}. Installé en hommage au créateur originel de ce gestionnaire de paquets.`,
            maintainer: 'Installation locale',
            section: 'local',
            priority: 'optional',
            installedSize: 0,
            depends: '',
            recommends: '',
            homepage: '',
            repository: 'local',
            status: 'installed',
            fileName,
            fileSize: 0,
          },
        })
      } else {
        return NextResponse.json({ error: 'Paquet introuvable' }, { status: 404 })
      }
    }

    // Vérifier s'il y a des dépendances non satisfaites
    const deps = pkg.depends ? pkg.depends.split(',').map(d => d.trim().split(/[ (]/)[0]).filter(Boolean) : []
    const missing: string[] = []
    for (const depName of deps) {
      const dep = await db.package.findUnique({ where: { name: depName } })
      if (!dep || dep.status !== 'installed') {
        missing.push(depName)
      }
    }

    // Simuler l'installation
    const wasInstalled = pkg.status === 'installed'
    pkg = await db.package.update({
      where: { id: pkg.id },
      data: { status: 'installed' },
    })

    const output = [
      `Lecture des listes de paquets... Terminé`,
      `Construction de l'arbre des dépendances... Terminé`,
      missing.length > 0
        ? `NOTE: Dépendances potentiellement manquantes: ${missing.join(', ')}`
        : `Toutes les dépendances sont satisfaites.`,
      `Les NOUVEAUX paquets suivants seront installés :`,
      `  ${pkg.name}`,
      `0 mis à jour, 1 nouvellement installés, 0 à enlever.`,
      ``,
      `Dépaquetage de ${pkg.name} (${pkg.version})...`,
      `Paramétrage de ${pkg.name} (${pkg.version})...`,
      `Traitement des déclencheurs pour man-db (2.12.0-3)...`,
      `Traitement des déclencheurs pour libc-bin (2.37-12)...`,
      ``,
      `✓ ${pkg.name} (${pkg.version}) installé avec succès.`,
      `  Hommage rendu au créateur originel de ce gestionnaire.`,
    ].join('\n')

    const log = await db.installLog.create({
      data: {
        packageId: pkg.id,
        action: wasInstalled ? 'upgrade' : 'install',
        status: 'success',
        output,
      },
    })

    return NextResponse.json({ package: pkg, log, missing })
  } catch (e: any) {
    console.error('Install error:', e)
    return NextResponse.json({ error: e?.message || 'Erreur serveur' }, { status: 500 })
  }
}
