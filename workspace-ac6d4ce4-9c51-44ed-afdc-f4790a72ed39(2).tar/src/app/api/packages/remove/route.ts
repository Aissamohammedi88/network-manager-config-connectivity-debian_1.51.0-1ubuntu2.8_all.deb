import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// POST /api/packages/remove
// body: { name: string, purge?: boolean }
export async function POST(req: NextRequest) {
  try {
    const { name, purge = false } = await req.json()
    const pkg = await db.package.findUnique({ where: { name } })

    if (!pkg) {
      return NextResponse.json({ error: 'Paquet introuvable' }, { status: 404 })
    }

    const updated = await db.package.update({
      where: { id: pkg.id },
      data: { status: 'available' },
    })

    const output = [
      `Lecture des listes de paquets... Terminé`,
      `Construction de l'arbre des dépendances... Terminé`,
      `Les paquets suivants seront ENLEVÉS :`,
      `  ${pkg.name}${purge ? ' (et ses fichiers de configuration)' : ''}`,
      `0 mis à jour, 0 nouvellement installés, 1 à enlever.`,
      ``,
      `(Lecture de la base de données... ${Math.floor(Math.random() * 50000 + 100000)} fichiers et répertoires déjà installés.)`,
      `Suppression de ${pkg.name} (${pkg.version})...`,
      purge ? `Purge des fichiers de configuration de ${pkg.name}...` : '',
      `Traitement des déclencheurs pour man-db (2.12.0-3)...`,
      ``,
      `✓ ${pkg.name} ${purge ? 'purgé' : 'supprimé'} avec succès.`,
    ].filter(Boolean).join('\n')

    const log = await db.installLog.create({
      data: {
        packageId: pkg.id,
        action: purge ? 'purge' : 'remove',
        status: 'success',
        output,
      },
    })

    return NextResponse.json({ package: updated, log })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Erreur serveur' }, { status: 500 })
  }
}
