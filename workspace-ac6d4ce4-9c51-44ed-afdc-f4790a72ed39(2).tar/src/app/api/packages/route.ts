import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/packages - liste avec filtres
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const search = searchParams.get('search') || ''
  const status = searchParams.get('status') || ''
  const section = searchParams.get('section') || ''
  const limit = Number(searchParams.get('limit') || 200)

  const where: any = {}
  if (search) {
    where.OR = [
      { name: { contains: search } },
      { description: { contains: search } },
      { maintainer: { contains: search } },
    ]
  }
  if (status && status !== 'all') where.status = status
  if (section && section !== 'all') where.section = section

  const packages = await db.package.findMany({
    where,
    orderBy: { name: 'asc' },
    take: limit,
  })
  return NextResponse.json({ packages })
}
