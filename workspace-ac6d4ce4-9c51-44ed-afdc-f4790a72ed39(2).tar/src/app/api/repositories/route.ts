import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/repositories
export async function GET() {
  const repos = await db.repository.findMany({
    orderBy: { name: 'asc' },
  })
  return NextResponse.json({ repositories: repos })
}

// PATCH /api/repositories - basculer enabled
export async function PATCH(req: Request) {
  const { id, enabled } = await req.json()
  const repo = await db.repository.update({
    where: { id },
    data: { enabled },
  })
  return NextResponse.json({ repository: repo })
}
