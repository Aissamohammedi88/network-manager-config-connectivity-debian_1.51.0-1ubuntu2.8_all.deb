import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/stats
export async function GET() {
  const total = await db.package.count()
  const installed = await db.package.count({ where: { status: 'installed' } })
  const available = await db.package.count({ where: { status: 'available' } })
  const upgradable = await db.package.count({ where: { status: 'upgradable' } })

  const totalInstalledSize = await db.package.aggregate({
        _sum: { installedSize: true },
        where: { status: 'installed' },
      })

  const bySection = await db.package.groupBy({
    by: ['section'],
    _count: { _all: true },
    orderBy: { _count: { section: 'desc' } },
    take: 8,
  })

  const recentLogs = await db.installLog.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    include: { package: true },
  })

  return NextResponse.json({
    total,
    installed,
    available,
    upgradable,
    totalInstalledSize: totalInstalledSize._sum.installedSize || 0,
    bySection,
    recentLogs,
  })
}
