'use client'

import { useEffect, useState, useMemo } from 'react'
import { Search, Package, Download, Trash2, HardDrive, Activity, ChevronRight, Terminal, ShieldCheck, Database, Boxes, Flame, Heart, Plus } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'
import { Toaster } from '@/components/ui/sonner'

type Pkg = {
  id: string
  name: string
  version: string
  architecture: string
  description: string
  maintainer: string
  section: string
  priority: string
  installedSize: number
  depends: string
  recommends: string
  homepage: string
  repository: string
  status: string
  fileName: string
  fileSize: number
  createdAt: string
  updatedAt: string
}

type Repo = {
  id: string
  name: string
  url: string
  suite: string
  components: string
  enabled: boolean
  packages: number
}

type LogEntry = {
  id: string
  action: string
  status: string
  output: string
  createdAt: string
  package: { name: string; version: string }
}

type Memorial = {
  id: string
  author: string
  years: string
  message: string
  relation: string
  createdAt: string
}

type Stats = {
  total: number
  installed: number
  available: number
  upgradable: number
  totalInstalledSize: number
  bySection: { section: string; _count: { _all: number } }[]
  recentLogs: LogEntry[]
}

function formatSize(kb: number) {
  if (kb < 1024) return `${kb} Ko`
  if (kb < 1024 * 1024) return `${(kb / 1024).toFixed(1)} Mo`
  return `${(kb / 1024 / 1024).toFixed(2)} Go`
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  })
}

const SECTIONS = ['all', 'net', 'admin', 'web', 'editors', 'vcs', 'utils', 'python', 'javascript', 'gnome', 'database', 'video', 'graphics', 'httpd']

export default function Home() {
  const [packages, setPackages] = useState<Pkg[]>([])
  const [repos, setRepos] = useState<Repo[]>([])
  const [logs, setLogs] = useState<LogEntry[]>([])
  const [memorials, setMemorials] = useState<Memorial[]>([])
  const [stats, setStats] = useState<Stats | null>(null)

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [sectionFilter, setSectionFilter] = useState('all')
  const [selectedPkg, setSelectedPkg] = useState<Pkg | null>(null)

  const [installing, setInstalling] = useState<string | null>(null)
  const [removing, setRemoving] = useState<string | null>(null)
  const [terminalOutput, setTerminalOutput] = useState<string[]>([
    '$ sudo apt update',
    'Atteint : http://deb.debian.org/debian bookworm InRelease',
    'Atteint : http://deb.debian.org/debian bookworm/main amd64 Packages',
    'Lecture des listes de paquets... Terminé',
    'Construction de l\'arbre des dépendances... Terminé',
    '21 paquets peuvent être mis à jour. Exécutez « apt list --upgradable » pour les voir.',
    '',
    '$ En hommage au créateur originel. Repose en paix.',
  ])

  // Memorial dialog
  const [memorialOpen, setMemorialOpen] = useState(false)
  const [memorialForm, setMemorialForm] = useState({ author: '', years: '', message: '', relation: '' })

  const fetchData = async () => {
    const params = new URLSearchParams()
    if (search) params.set('search', search)
    if (statusFilter !== 'all') params.set('status', statusFilter)
    if (sectionFilter !== 'all') params.set('section', sectionFilter)

    const [pkgRes, repoRes, logRes, memRes, statsRes] = await Promise.all([
      fetch(`/api/packages?${params}`),
      fetch('/api/repositories'),
      fetch('/api/logs'),
      fetch('/api/memorial'),
      fetch('/api/stats'),
    ])

    const [pkgData, repoData, logData, memData, statsData] = await Promise.all([
      pkgRes.json(), repoRes.json(), logRes.json(), memRes.json(), statsRes.json(),
    ])

    setPackages(pkgData.packages || [])
    setRepos(repoData.repositories || [])
    setLogs(logData.logs || [])
    setMemorials(memData.memorials || [])
    setStats(statsData)
  }

  useEffect(() => {
    fetchData()
  }, [search, statusFilter, sectionFilter])

  const installPkg = async (pkg: Pkg) => {
    setInstalling(pkg.id)
    try {
      const res = await fetch('/api/packages/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: pkg.name }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Erreur')

      setTerminalOutput(prev => [
        ...prev,
        '',
        `$ sudo apt install ./${pkg.fileName}`,
        ...data.log.output.split('\n'),
      ])

      if (data.missing?.length) {
        toast.warning(`${pkg.name} installé`, {
          description: `Dépendances potentiellement manquantes: ${data.missing.join(', ')}`,
        })
      } else {
        toast.success(`${pkg.name} installé avec succès`, {
          description: 'Hommage rendu au créateur originel.',
        })
      }

      await fetchData()
      setSelectedPkg(data.package)
    } catch (e: any) {
      toast.error("Échec de l'installation", { description: e.message })
    } finally {
      setInstalling(null)
    }
  }

  const installLocalDeb = async () => {
    const fileName = 'network-manager-config-connectivity-debian_1.46.0-1ubuntu2.8_all.deb'
    setInstalling('local-deb')
    try {
      const res = await fetch('/api/packages/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Erreur')

      setTerminalOutput(prev => [
        ...prev,
        '',
        `$ sudo apt install ./${fileName}`,
        ...data.log.output.split('\n'),
      ])

      toast.success(`Paquet local installé : ${fileName}`, {
        description: 'Hommage perpétuel au créateur originel.',
      })

      await fetchData()
    } catch (e: any) {
      toast.error("Échec de l'installation du .deb local", { description: e.message })
    } finally {
      setInstalling(null)
    }
  }

  const removePkg = async (pkg: Pkg) => {
    setRemoving(pkg.id)
    try {
      const res = await fetch('/api/packages/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: pkg.name, purge: false }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Erreur')

      setTerminalOutput(prev => [
        ...prev,
        '',
        `$ sudo apt remove ${pkg.name}`,
        ...data.log.output.split('\n'),
      ])

      toast.success(`${pkg.name} supprimé`)
      await fetchData()
      setSelectedPkg(data.package)
    } catch (e: any) {
      toast.error('Échec de la suppression', { description: e.message })
    } finally {
      setRemoving(null)
    }
  }

  const toggleRepo = async (repo: Repo, enabled: boolean) => {
    try {
      await fetch('/api/repositories', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: repo.id, enabled }),
      })
      toast.success(`${repo.name} ${enabled ? 'activé' : 'désactivé'}`)
      fetchData()
    } catch (e: any) {
      toast.error('Erreur', { description: e.message })
    }
  }

  const submitMemorial = async () => {
    if (!memorialForm.author || !memorialForm.message) {
      toast.error('Veuillez remplir au moins le nom et le message')
      return
    }
    try {
      const res = await fetch('/api/memorial', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(memorialForm),
      })
      if (!res.ok) throw new Error('Erreur')
      toast.success('Hommage ajouté. Merci.')
      setMemorialForm({ author: '', years: '', message: '', relation: '' })
      setMemorialOpen(false)
      fetchData()
    } catch (e: any) {
      toast.error("Échec de l'ajout", { description: e.message })
    }
  }

  const clearTerminal = () => setTerminalOutput(['$ Terminal effacé.'])

  const statsCards = useMemo(() => {
    if (!stats) return null
    return [
      { label: 'Paquets totaux', value: stats.total, icon: Boxes, color: 'text-emerald-600' },
      { label: 'Installés', value: stats.installed, icon: Package, color: 'text-blue-600' },
      { label: 'Disponibles', value: stats.available, icon: Download, color: 'text-orange-600' },
      { label: 'Taille installée', value: formatSize(stats.totalInstalledSize), icon: HardDrive, color: 'text-purple-600' },
    ]
  }, [stats])

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      <Toaster richColors position="top-right" />

      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-white/80 backdrop-blur-lg dark:bg-slate-950/80 border-slate-200 dark:border-slate-800">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-rose-500 via-red-500 to-orange-500 flex items-center justify-center shadow-lg">
                <Package className="w-5 h-5 text-white" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-rose-500 rounded-full ring-2 ring-white dark:ring-slate-950 animate-pulse" />
              </div>
              <div>
                <h1 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">
                  Cousin Debian Manager
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  En hommage au créateur originel — Repose en paix
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={installLocalDeb}
                disabled={installing === 'local-deb'}
              >
                {installing === 'local-deb' ? (
                  <>
                    <Activity className="w-3 h-3 mr-2 animate-pulse" />
                    Installation...
                  </>
                ) : (
                  <>
                    <Download className="w-3 h-3 mr-2" />
                    Installer le .deb local
                  </>
                )}
              </Button>
              <Dialog open={memorialOpen} onOpenChange={setMemorialOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Heart className="w-3 h-3 mr-2 text-rose-500" />
                    Hommage
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Ajouter un hommage</DialogTitle>
                    <DialogDescription>
                      Laissez un message en l'honneur du créateur défunt.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <Label htmlFor="author">Votre nom</Label>
                      <Input id="author" value={memorialForm.author}
                        onChange={e => setMemorialForm({ ...memorialForm, author: e.target.value })}
                        placeholder="Ex: Cousin éloigné" />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <Label htmlFor="years">Années</Label>
                        <Input id="years" value={memorialForm.years}
                          onChange={e => setMemorialForm({ ...memorialForm, years: e.target.value })}
                          placeholder="1985 - 2024" />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="relation">Relation</Label>
                        <Input id="relation" value={memorialForm.relation}
                          onChange={e => setMemorialForm({ ...memorialForm, relation: e.target.value })}
                          placeholder="Cousin" />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="message">Message</Label>
                      <Textarea id="message" value={memorialForm.message}
                        onChange={e => setMemorialForm({ ...memorialForm, message: e.target.value })}
                        placeholder="Ton héritage vit à travers..." rows={4} />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setMemorialOpen(false)}>Annuler</Button>
                    <Button onClick={submitMemorial}>
                      <Plus className="w-3 h-3 mr-2" />
                      Déposer l'hommage
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>

      {/* Memorial Banner */}
      <section className="border-b bg-gradient-to-r from-rose-50 via-orange-50 to-amber-50 dark:from-rose-950/30 dark:via-orange-950/30 dark:to-amber-950/30 border-rose-100 dark:border-rose-900">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-start gap-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Flame className="w-4 h-4 text-rose-500" />
                <span className="text-xs font-semibold tracking-wider uppercase text-rose-700 dark:text-rose-300">
                  Mémorial
                </span>
              </div>
              <p className="text-sm italic text-slate-700 dark:text-slate-300 leading-relaxed">
                « {memorials[0]?.message || 'En mémoire du créateur originel de ce gestionnaire de paquets Debian.'} »
              </p>
              <p className="text-xs mt-1 text-rose-700/80 dark:text-rose-300/80">
                — {memorials[0]?.author || 'Votre Cousin'}{memorials[0]?.years ? `, ${memorials[0].years}` : ''}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Main */}
      <main className="flex-1 container mx-auto px-4 py-6">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          {statsCards?.map((s, i) => (
            <Card key={i} className="overflow-hidden border-slate-200 dark:border-slate-800">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{s.label}</p>
                    <p className="text-2xl font-bold mt-1 text-slate-900 dark:text-white">{s.value}</p>
                  </div>
                  <s.icon className={`w-8 h-8 ${s.color} opacity-80`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabs */}
        <Tabs defaultValue="packages" className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 mb-4">
            <TabsTrigger value="packages" className="text-xs sm:text-sm">
              <Package className="w-3 h-3 mr-1.5" />
              Paquets
            </TabsTrigger>
            <TabsTrigger value="terminal" className="text-xs sm:text-sm">
              <Terminal className="w-3 h-3 mr-1.5" />
              Terminal
            </TabsTrigger>
            <TabsTrigger value="repos" className="text-xs sm:text-sm">
              <Database className="w-3 h-3 mr-1.5" />
              Dépôts
            </TabsTrigger>
            <TabsTrigger value="memorial" className="text-xs sm:text-sm">
              <Heart className="w-3 h-3 mr-1.5" />
              Hommages
            </TabsTrigger>
          </TabsList>

          {/* PAQUETS */}
          <TabsContent value="packages" className="space-y-4">
            {/* Filters */}
            <Card className="border-slate-200 dark:border-slate-800">
              <CardContent className="p-3">
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      placeholder="Rechercher un paquet, une description, un mainteneur..."
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="Statut" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous statuts</SelectItem>
                      <SelectItem value="installed">Installés</SelectItem>
                      <SelectItem value="available">Disponibles</SelectItem>
                      <SelectItem value="upgradable">Mises à jour</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={sectionFilter} onValueChange={setSectionFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <SelectValue placeholder="Section" />
                    </SelectTrigger>
                    <SelectContent>
                      {SECTIONS.map(s => (
                        <SelectItem key={s} value={s}>
                          {s === 'all' ? 'Toutes sections' : s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Liste paquets */}
              <div className="lg:col-span-1 space-y-2 max-h-[calc(100vh-340px)] overflow-y-auto pr-1 custom-scroll">
                {packages.length === 0 && (
                  <Card className="border-dashed">
                    <CardContent className="py-8 text-center text-sm text-slate-500">
                      Aucun paquet trouvé.
                    </CardContent>
                  </Card>
                )}
                {packages.map(pkg => (
                  <button
                    key={pkg.id}
                    onClick={() => setSelectedPkg(pkg)}
                    className={`w-full text-left p-3 rounded-lg border transition-all ${
                      selectedPkg?.id === pkg.id
                        ? 'border-rose-400 bg-rose-50 dark:bg-rose-950/30 dark:border-rose-800'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm font-semibold text-slate-900 dark:text-white truncate">
                            {pkg.name}
                          </span>
                          {pkg.status === 'installed' && (
                            <Badge variant="outline" className="bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900 text-[10px] py-0 px-1.5">
                              installé
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                          {pkg.description}
                        </p>
                        <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-400">
                          <span className="font-mono">{pkg.version}</span>
                          <span>•</span>
                          <span>{pkg.section}</span>
                          <span>•</span>
                          <span>{pkg.architecture}</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    </div>
                  </button>
                ))}
              </div>

              {/* Détail paquet */}
              <div className="lg:col-span-2">
                {selectedPkg ? (
                  <Card className="border-slate-200 dark:border-slate-800">
                    <CardHeader className="pb-3 border-b border-slate-100 dark:border-slate-800">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <CardTitle className="font-mono text-base text-slate-900 dark:text-white">
                            {selectedPkg.name}
                          </CardTitle>
                          <CardDescription className="mt-1">
                            {selectedPkg.maintainer}
                          </CardDescription>
                        </div>
                        <div className="flex items-center gap-1.5">
                          {selectedPkg.status === 'installed' ? (
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => removePkg(selectedPkg)}
                              disabled={removing === selectedPkg.id}
                            >
                              {removing === selectedPkg.id ? (
                                <Activity className="w-3 h-3 mr-1 animate-pulse" />
                              ) : (
                                <Trash2 className="w-3 h-3 mr-1" />
                              )}
                              Supprimer
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => installPkg(selectedPkg)}
                              disabled={installing === selectedPkg.id}
                              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                            >
                              {installing === selectedPkg.id ? (
                                <Activity className="w-3 h-3 mr-1 animate-pulse" />
                              ) : (
                                <Download className="w-3 h-3 mr-1" />
                              )}
                              Installer
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4 space-y-4 max-h-[calc(100vh-440px)] overflow-y-auto custom-scroll">
                      <div>
                        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Description</h4>
                        <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-300">
                          {selectedPkg.description}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <span className="text-slate-500">Version :</span>{' '}
                          <span className="font-mono text-slate-900 dark:text-white">{selectedPkg.version}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Architecture :</span>{' '}
                          <span className="font-mono text-slate-900 dark:text-white">{selectedPkg.architecture}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Section :</span>{' '}
                          <Badge variant="secondary" className="text-[10px] py-0">{selectedPkg.section}</Badge>
                        </div>
                        <div>
                          <span className="text-slate-500">Priorité :</span>{' '}
                          <span className="text-slate-900 dark:text-white">{selectedPkg.priority}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Taille installée :</span>{' '}
                          <span className="text-slate-900 dark:text-white">{formatSize(selectedPkg.installedSize)}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Taille .deb :</span>{' '}
                          <span className="text-slate-900 dark:text-white">{formatSize(Math.floor(selectedPkg.fileSize / 1024))}</span>
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                          Fichier .deb
                        </h4>
                        <code className="block text-xs font-mono p-2 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 overflow-x-auto">
                          {selectedPkg.fileName}
                        </code>
                      </div>

                      {selectedPkg.depends && (
                        <div>
                          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                            Dépendances
                          </h4>
                          <div className="flex flex-wrap gap-1">
                            {selectedPkg.depends.split(',').map(d => d.trim()).map((d, i) => (
                              <Badge key={i} variant="outline" className="font-mono text-[10px]">
                                {d}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {selectedPkg.recommends && (
                        <div>
                          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                            Recommandations
                          </h4>
                          <div className="flex flex-wrap gap-1">
                            {selectedPkg.recommends.split(',').map(d => d.trim()).map((d, i) => (
                              <Badge key={i} variant="outline" className="font-mono text-[10px] text-slate-500">
                                {d}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {selectedPkg.homepage && (
                        <div>
                          <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">Page d'accueil</h4>
                          <a
                            href={selectedPkg.homepage}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-rose-600 dark:text-rose-400 hover:underline break-all"
                          >
                            {selectedPkg.homepage}
                          </a>
                        </div>
                      )}

                      <Separator />

                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Vérifié par la clé du dépôt</span>
                        <span>•</span>
                        <span>Dépôt : <span className="font-mono">{selectedPkg.repository}</span></span>
                      </div>

                      {/* Pour le paquet mentionné, ajouter une note spéciale */}
                      {selectedPkg.name === 'network-manager-config-connectivity-debian' && (
                        <div className="p-3 rounded-lg bg-gradient-to-r from-rose-50 to-orange-50 dark:from-rose-950/30 dark:to-orange-950/30 border border-rose-200 dark:border-rose-900">
                          <div className="flex items-center gap-2 mb-1">
                            <Heart className="w-3.5 h-3.5 text-rose-500" />
                            <span className="text-xs font-semibold text-rose-700 dark:text-rose-300">
                              Paquet dédié
                            </span>
                          </div>
                          <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                            Ce paquet est spécialement dédié à la mémoire de votre cousin, créateur originel de ce gestionnaire de paquets Debian. Chaque installation perpétue son héritage.
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ) : (
                  <Card className="border-dashed border-slate-300 dark:border-slate-700">
                    <CardContent className="py-16 text-center">
                      <Package className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Sélectionnez un paquet pour voir ses détails
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* TERMINAL */}
          <TabsContent value="terminal">
            <Card className="border-slate-800 bg-slate-950 dark:bg-slate-950">
              <CardHeader className="border-b border-slate-800 py-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    </div>
                    <span className="ml-2 text-xs text-slate-400 font-mono">
                      root@cousin-debian:~#
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" className="text-xs text-slate-400 hover:text-slate-200" onClick={clearTerminal}>
                    Effacer
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[calc(100vh-340px)] w-full">
                  <pre className="p-4 text-xs font-mono text-emerald-400 whitespace-pre-wrap break-words leading-relaxed">
                    {terminalOutput.join('\n')}
                    {'\n\n'}<span className="text-slate-500">$</span>{' '}
                    <span className="inline-block w-2 h-3.5 bg-emerald-400 animate-pulse align-middle" />
                  </pre>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* DÉPÔTS */}
          <TabsContent value="repos">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {repos.map(repo => (
                <Card key={repo.id} className="border-slate-200 dark:border-slate-800">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className="min-w-0">
                        <CardTitle className="text-sm text-slate-900 dark:text-white">
                          {repo.name}
                        </CardTitle>
                        <CardDescription className="font-mono text-xs mt-1 break-all">
                          {repo.url} {repo.suite}
                        </CardDescription>
                      </div>
                      <Switch
                        checked={repo.enabled}
                        onCheckedChange={(v) => toggleRepo(repo, v)}
                      />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center gap-2 flex-wrap text-xs">
                      <Badge variant="outline" className="text-[10px]">{repo.components}</Badge>
                      <span className="text-slate-500">{repo.packages.toLocaleString('fr-FR')} paquets</span>
                    </div>
                    <div className="pt-1">
                      <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                        <span>Composants actifs</span>
                        <span>{repo.enabled ? 'Activé' : 'Désactivé'}</span>
                      </div>
                      <Progress value={repo.enabled ? 100 : 0} className="h-1" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* MÉMORIAL */}
          <TabsContent value="memorial" className="space-y-4">
            <Card className="border-rose-200 dark:border-rose-900 bg-gradient-to-br from-rose-50/50 via-white to-orange-50/50 dark:from-rose-950/20 dark:via-slate-900 dark:to-orange-950/20">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-rose-500" />
                  <CardTitle className="text-base">Livre d'or — Hommages</CardTitle>
                </div>
                <CardDescription>
                  En mémoire des créateurs qui nous ont quittés. Leur code continue de faire tourner le monde.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {memorials.map(m => (
                  <div key={m.id} className="border-l-2 border-rose-300 dark:border-rose-700 pl-4 py-1">
                    <p className="text-sm italic text-slate-700 dark:text-slate-300 leading-relaxed">
                      « {m.message} »
                    </p>
                    <p className="text-xs mt-2 text-rose-700 dark:text-rose-300">
                      <span className="font-semibold">— {m.author}</span>
                      {m.years ? <span className="opacity-70">, {m.years}</span> : null}
                      <span className="opacity-70"> · {m.relation}</span>
                    </p>
                    <p className="text-[10px] mt-1 text-slate-400">
                      Déposé le {formatDate(m.createdAt)}
                    </p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recent activity */}
            <Card className="border-slate-200 dark:border-slate-800">
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-500" />
                  Activité récente
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-72 overflow-y-auto custom-scroll">
                {logs.length === 0 && (
                  <p className="text-xs text-slate-500 text-center py-4">Aucune activité.</p>
                )}
                {logs.map(log => (
                  <div key={log.id} className="flex items-center gap-3 py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-0">
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                      log.action === 'install' ? 'bg-emerald-500' :
                      log.action === 'remove' ? 'bg-rose-500' :
                      log.action === 'purge' ? 'bg-orange-500' : 'bg-blue-500'
                    }`} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs">
                        <span className="font-mono font-semibold text-slate-900 dark:text-white">
                          {log.package.name}
                        </span>
                        <span className="text-slate-500"> — {log.action}</span>
                        <Badge variant="outline" className="ml-2 text-[9px] py-0 h-4">
                          {log.status}
                        </Badge>
                      </p>
                      <p className="text-[10px] text-slate-400">{formatDate(log.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/80 backdrop-blur-lg dark:bg-slate-950/80 border-slate-200 dark:border-slate-800 mt-auto">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-2">
              <Heart className="w-3 h-3 text-rose-500" />
              <span>
                Cousin Debian Manager — En hommage éternel au créateur originel.
              </span>
            </div>
            <div className="flex items-center gap-3">
              <span>Debian est une marque de SPI.</span>
              <span>•</span>
              <span className="font-mono">v1.0.0-mémorial</span>
            </div>
          </div>
        </div>
      </footer>

      <style jsx global>{`
        .custom-scroll::-webkit-scrollbar { width: 6px; height: 6px; }
        .custom-scroll::-webkit-scrollbar-track { background: transparent; }
        .custom-scroll::-webkit-scrollbar-thumb { background: rgba(148,163,184,0.4); border-radius: 3px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: rgba(148,163,184,0.7); }
      `}</style>
    </div>
  )
}
